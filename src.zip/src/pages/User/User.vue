<template>
  <div>
    user
  </div>
</template>

<script>
export default {
  name:"User"
}
</script>

<style>

</style>