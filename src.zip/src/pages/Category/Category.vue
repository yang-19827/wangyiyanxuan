<template>
  <div>
    分类
  </div>
</template>

<script>
export default {
  name:"Category"
}
</script>

<style>

</style>