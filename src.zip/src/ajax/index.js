import index from './index/index'
export default {
  index
}