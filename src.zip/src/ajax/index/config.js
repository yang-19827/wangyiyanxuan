export default{
  api:{
    getIndexData:{
      url:"/getIndexData",
      corsUrl: '/3002',
      method:"get",
      isToast:false,
    },
  },
  name:'index',
}