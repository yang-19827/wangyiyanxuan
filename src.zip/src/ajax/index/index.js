import contactAxios from './axios'
import config from './config'
import ajaxUtil from '@/util/ajax.js'
export default ajaxUtil(contactAxios,config)